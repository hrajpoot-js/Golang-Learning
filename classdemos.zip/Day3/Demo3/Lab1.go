package main


import(
	"fmt"
	"strconv"
)

type display interface {
	Print() 
}

type Emp struct {
	empno int 
	ename string
	salary int
}
type Product struct {
	prod int 
	prodname string
}

func (e Product) Print()  {
	str :="Product Details[Prodno = "+ strconv.Itoa(e.prod)+ " , ProdName = " + e.prodname +"]" ;
	fmt.Println(str)
}

func (e Emp) Print()  {
	str :="Emp Details[Empno = "+ strconv.Itoa(e.empno)+ " , Name = " + e.ename +"]" ;
	fmt.Println(str)
}


func main(){
	ch := "e"
	fmt.Println(ch)
	fmt.Println("Enter E for Emp and p for Product")
	fmt.Scanln(&ch)
	fmt.Println("Current Ch = ", ch)
	var obj display
	if ch =="E" {
		obj = Emp{1,"aa",111}
	}
	if ch =="P" {
		obj = Product{11,"Pen"}
	}
	obj.Print()
 }
