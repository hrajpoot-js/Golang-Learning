package main


import(
	"fmt"
	"strings"
)

type Convert interface {
	toUpper() string
}
type Emp struct {
	empno int 
	ename string
	salary int
}


func (e Emp) toUpper() string  {
	return "TOUPPER"+ strings.ToUpper(e.ename)
}

func main(){
	var obj Convert
	obj = Emp{1,"aa",111}
	
	fmt.Println(obj.toUpper())
 }
