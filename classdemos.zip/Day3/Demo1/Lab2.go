package main


import(
	"fmt"
)
type Emp struct {
	empno int 
	ename string
	salary int
}

func main(){
	var mymap map[int]Emp 
	mymap = make(map[int]Emp)
	mymap[1] = Emp{1,"One",1111}
	mymap[2] = Emp{2,"Two",2222}
	
	fmt.Println(mymap)
}