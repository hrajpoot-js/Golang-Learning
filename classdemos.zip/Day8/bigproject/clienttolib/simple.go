package main

import (
    "fmt"
    "example.com/lib1"
)

func main() {
    // Get a greeting message and print it.
    message := lib1.Hello("ABCd")
    fmt.Println(message)
}