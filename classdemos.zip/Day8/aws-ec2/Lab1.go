package main

import (
    "github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/ec2"

    "fmt"
)

func main() {
	sess, err := session.NewSession(&aws.Config{
		Region: aws.String("us-east-1"),
	})

    ec2Svc := ec2.New(sess)

    result, err := ec2Svc.DescribeInstances(nil)
    if err != nil {
        fmt.Println("Error", err)
    } else {
 			for i, v := range result.Reservations {
				for j, v1 := range v.Instances {	
					fmt.Println("Reservation ", i, "Instance " , j , "InstanceId : = ",*v1.InstanceId , " Tags " , v1.Tags)
					fmt.Println("===========================")
				}
				fmt.Println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
  			}
		}
	}