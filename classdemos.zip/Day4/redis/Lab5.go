package main

import (
	"fmt"
	"github.com/go-redis/redis"
)

func main() {
	fmt.Println("Go Redis Tutorial")

	client := redis.NewClient(&redis.Options{
		Addr: "localhost:6379",
		Password: "",
		DB: 0,
	})

	pong, err := client.Ping().Result()
	fmt.Println(pong, err)

	
val, err := client.Get("name").Result()
if err != nil {
    fmt.Println(err)
}

fmt.Println("Name value initially "  ,val)
	err = client.Set("name", "Check1", 0).Err()
// if there has been an error setting the value
// handle the error
if err != nil {
    fmt.Println(err)
}


val, err = client.Get("name").Result()
if err != nil {
    fmt.Println(err)
}

fmt.Println("Name value after set  "  ,val)

}