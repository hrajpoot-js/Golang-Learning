package main
import (
    "go.mongodb.org/mongo-driver/mongo"
    "go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/bson"
    "context"
	"log"
	"time"
	"fmt"
	
)

func main(){
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	client, err := mongo.Connect(ctx, options.Client().ApplyURI(
	   "mongodb+srv://dbuser:mypassword@cluster0.m7uzk.mongodb.net/?retryWrites=true&w=majority",
	))
	hoonardatabase := client.Database("hoonar")
    deptcollection := hoonardatabase.Collection("dept")
	insertresult, err := deptcollection.InsertOne(ctx, bson.D{
		{Key: "_id", Value: "2"},
		{Key: "dname", Value: "HR"},
		{Key:"loc",Value:"Blr"},
	})

	fmt.Println(insertresult)
	if err != nil { log.Fatal(err) }
}

