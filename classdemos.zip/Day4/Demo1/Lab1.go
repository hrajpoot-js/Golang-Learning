package main

import (
	"fmt"
)
func print(str string){
	for i:=0;i<500;i++{
		fmt.Print(str)
	}
}

func main(){

	go print(".")
	go print("x")
	// wait till all threads get over
	fmt.Println("World")
	// sleep 10 seconds
	// accept some details from user
	// code which takes longer time
	for {}
}