package main

import (
	"fmt"
)
func (emp *Emp) show() {
	fmt.Println("show " , emp)
}
func NewEmp(empno int) *Emp {
    
    e := new(Emp)
   e.empno = empno
    return e
}

type Emp struct {
	empno int 
	ename string
	salary int
}
func main(){
	emp :=new (Emp)

	/*
	emp.empno =1
	emp.ename="aa"
	emp.salary =10
	*/
	emp.show()
	emp1 := new Emp(10)
	emp1.show()
}