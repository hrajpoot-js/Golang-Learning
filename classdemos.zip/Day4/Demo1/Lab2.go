package main

import (
	"fmt"
	"time"
)
func add(i, j int, ch chan int)  {
	fmt.Println("add invoked with " ,i , "  , " , j)
	time.Sleep(2* time.Second)
	fmt.Println("two seconds sleep over, send data back")
	ch <- (i+j)
	fmt.Println("in add after ch send 1")
}

func main(){
	ch := make(chan int)
	go add(10,3000, ch)
	fmt.Println("main - 5 seconds sleep over")
	sum := <-ch  
	fmt.Println("sum = "  , sum)
	fmt.Println("main sleeping again for 5 seconds")
	time.Sleep(5* time.Second)
}