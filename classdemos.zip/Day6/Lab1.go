package main

import (
	"fmt"
	"strconv"
)

func Hello(str string) string {
	fmt.Println("hello invoked with ", str)
	return "hello, " + str
}
func Add(no1 int, no2 int) int {
	fmt.Println("add invoked with ", no1, ",", no2)
	return no1 + no2
}
func Divide(s1 string, s2 string) int {
	// two types of errors
	//	1. invalid string where strconv gives errors
	//	2. second argument is zero
	fmt.Println("divide invoked with ", s1, ", ", s2)
	num1, _ := strconv.Atoi(s1)
	num2, _ := strconv.Atoi(s2)
	return num1 / num2
	/*
	   if err != nil {
	       fmt.Println("invalid string")
	       return -1
	   }

	   if num2 == 0 {
	       fmt.Println("second argument is zero")
	       return -1
	   }
	*/

}
func main() {
	fmt.Println("hello with fands returned ", Hello("fands"))
	fmt.Println("add with 10,40 returned ", Add(10, 40))
	fmt.Println("divide with 40,10 returned ", Divide("40", "10"))
	fmt.Println("divide with 40,a returned ", Divide("40", "a"))
	fmt.Println("divide with 40,0 returned ", Divide("40", "0"))
}
