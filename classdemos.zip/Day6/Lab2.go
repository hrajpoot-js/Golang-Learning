package main

import (
	"fmt"
	"strconv"
	"errors"
)

func Hello(str string) string {
	fmt.Println("hello invoked with ", str)
	return "hello, " + str
}
func Add(no1 int, no2 int) int {
	fmt.Println("add invoked with ", no1, ",", no2)
	return no1 + no2
}
func Divide(s1 string, s2 string) (int, error) {
	fmt.Println("divide invoked with ", s1, ", ", s2)
	num1, err1 := strconv.Atoi(s1)
	num2, err2 := strconv.Atoi(s2)
	if(err1 != nil || err2 !=nil) {
		return 0, err1
	}
	if(num2 == 0) {
		return 0, errors.New("Second Argument must be nonzero")
	}
	return num1 / num2, nil
}


/*
func Divide(s1 string, s2 string) (int, error) {
	defer func() {
		r := recover()
		fmt.Println("---------------recover ", r)
		if r != nil {
			fmt.Println("Recovered in f", r)
			
		}
	}()
	fmt.Println("divide invoked with ", s1, ", ", s2)
	num1, err := strconv.Atoi(s1)

	if(err != nil) {
		panic("Conversion Error")
	}
	num2, err := strconv.Atoi(s2)
	if(err != nil) {
		panic("Conversion Error")
	}
	ans:= num1 / num2
	return ans, nil
	}
*/
/*
func Divide(s1 string, s2 string) (int, error) {
	// two types of errors
	//	1. invalid string where strconv gives errors
	//	2. second argument is zero
	fmt.Println("divide invoked with ", s1, ", ", s2)
	num1, err := strconv.Atoi(s1)
	if err != nil {
		fmt.Println("invalid string")
		return 0,err
	}
	num2, err := strconv.Atoi(s2)
	 if err != nil {
	       fmt.Println("invalid string")
	       return 0,err
	   }
	 if num2 == 0 {
		fmt.Println("second argument is zero")
		return 0, err
	}
	return num1/num2, nil
}
*/
func main() {

	fmt.Println("hello with fands returned ", Hello("fands"))
	fmt.Println("add with 10,40 returned ", Add(10, 40))
	ans, err:=Divide("40", "10")

	fmt.Println("divide with 40,10 returned ", ans , " error = ", err )
	ans, err=Divide("40", "a")

	fmt.Println("divide with 40,a returned ", ans , " error = ", err )
	ans, err=Divide("40", "0")
	fmt.Println("divide with 40,0 returned ", ans , " error = ", err )
}
