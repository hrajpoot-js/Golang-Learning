package main

import (
	"fmt"
)
func hello(str string){
	fmt.Println("Hello func invoked with ", str)
}
func add(a, b int) int {
	fmt.Println("Add invoked with " , a ,"  and  "  , b)
	return a+b
}

func main(){
	var a, b int
	a,b =10,100
	fmt.Println("Hello ", a, "   " ,b)
	hello("a")
	fmt.Println("Add returned " , add(10,50) , " for 10 and 50")
	fmt.Println("Add returned " , add(10,500) , " for 10 and 50")
}