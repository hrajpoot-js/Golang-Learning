package main

import "fmt"
import "os"

func main() {
	fmt.Println("Hello World !!")
	hname, herr := os.Hostname()
	if herr == nil {
		fmt.Println("Hostname ", hname)
	} else {
		fmt.Println("Error  ", herr)
	}
}
