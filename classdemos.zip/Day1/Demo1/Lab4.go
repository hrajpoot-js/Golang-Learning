package main

import (
	"fmt"
)

func addsub(a, b int) (int, int) {
	fmt.Println("Addsub invoked with " , a ,"  and  "  , b)
	return a+b, a-b
}

func main(){
	sum, diff := addsub(100,50)
	fmt.Println("AddSub returned " , sum  , " and " , diff)
}