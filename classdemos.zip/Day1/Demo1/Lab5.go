package main

import (
	"fmt"
)

func addsub(a, b int) (n1, n2  int) {
	fmt.Println("Addsub invoked with " , a ,"  and  "  , b)
	n1, n2 = a+b, a-b
	return 
}

func main(){
	sum, diff := addsub(100,500)
	fmt.Println("AddSub returned " , sum  , " and " , diff)
}