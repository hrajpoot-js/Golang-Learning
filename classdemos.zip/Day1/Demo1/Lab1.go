// create a package
package main

// dependencies
import "fmt"

func main() {
	fmt.Println("Hello World !!")
}
