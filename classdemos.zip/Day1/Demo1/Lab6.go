package main
import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	
	clargs, _ := strconv.Atoi(os.Args[1])
	fmt.Println(clargs)
	t1, t2, nextTerm := 0, 1,1
	fmt.Print(t1, " ", t2 , " ")
	for  {
			t1, t2 = t2, nextTerm
			nextTerm = t1 + t2
			if nextTerm > clargs {
				break
			}
			fmt.Print( nextTerm, " ")
	}
}