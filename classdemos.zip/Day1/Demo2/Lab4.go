package main

import (
	"fmt"
	"log"
	"os"
)

func main() {
	file1 := os.Args[1]
	file2 := os.Args[2]
	// show error if file2 exists
	fmt.Println("Input file to be read", file1)
	defer fmt.Println("Output file to be write", file2)
	data, err := os.ReadFile(file1)
	if err != nil {
		log.Fatal("ReadFile Error ", err)
	} else {
		errw := os.WriteFile(file2, data, 0666)
		if errw != nil {
			log.Fatal("Write File Error ", errw)
		}
	}
}
