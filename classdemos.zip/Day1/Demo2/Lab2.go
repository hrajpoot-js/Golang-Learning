package main

import (
	"fmt"
)

func f1() {
	n1 := 100
	defer fmt.Println("------------defer f1 invoked and current value of n1 is ", n1)
	n1 = 4000
	fmt.Println("f1 invoked and current value of n1 is ", n1)

}

func f2() {
	fmt.Println("counting")
	for i := 0; i < 10; i++ {
		defer fmt.Println(i)
	}
	fmt.Println("done")
}
func main() {
	defer fmt.Println("Hello ")
	defer fmt.Println("Hello1 ")
	fmt.Println("World  ")
	f1()
	f2()
}
