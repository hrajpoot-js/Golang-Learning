package main

import (
	"fmt"
	"io"
	"encoding/json"
	"net/http"
//	"strconv"
)

type Emp struct {
	Empno  int     `json:"empno"`
	Ename  string  `json:"ename"`
	Salary int `json:"salary"`
}
type EmpManager struct {
	emparr []Emp 
}
func (empmgr *EmpManager) add(e1 Emp){
	empmgr.emparr = append(empmgr.emparr, e1)
}

func main() {
	empmgr := new(EmpManager)
	emp := Emp{1,"One",111}
	empmgr.add(emp)
	empmgr.add(Emp{2,"Two",222})
	fmt.Println("EmpMgr " , empmgr )
	handler := func(w http.ResponseWriter, req *http.Request) {
		fmt.Println("Call has come for ", req.Method)
		if (req.Method =="GET") {
			 bytearr, _ := json.Marshal(empmgr.emparr)
			io.WriteString(w,  string(bytearr))
		}
		if (req.Method =="POST") {
			fmt.Println("post request" , req.FormValue("empno"))
			emp1 := Emp{}
		// json 
			decoder := json.NewDecoder(req.Body)
			decoder.Decode(&emp1)
		/* // for form data
			emp1.Empno,_ = strconv.Atoi( req.FormValue("empno"))
			emp1.Ename = req.FormValue("ename")
			emp1.Salary,_ =strconv.Atoi( req.FormValue("salary"))
		*/
			empmgr.add(emp1)
		   io.WriteString(w,  string("hello from post"))
	   }
	}

	http.HandleFunc("/emp", handler)
	
	fmt.Printf("sever starting on 8080")
	http.ListenAndServe(":8080", nil)
}