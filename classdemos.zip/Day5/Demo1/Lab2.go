package main

import (
	"fmt"
	"io"
	"os"
	"net/http"
)

func readfile(str string) string {
	data, err := os.ReadFile(str)
	if err != nil {
		fmt.Println("Error reading file ", str)
		fmt.Println(err)
	}
	return string(data)
}

func main() {
	indexhandler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, readfile("static/index.html"))
	}
	page1handler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1>Page1 Page</h1>")
	}
	page2handler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1>Page2 Page</h1>")
	}
	http.HandleFunc("/", indexhandler)
	http.HandleFunc("/p1", page1handler)
	http.HandleFunc("/p2", page2handler)

	fmt.Printf("sever starting on 8080")
	http.ListenAndServe(":8080", nil)
}
