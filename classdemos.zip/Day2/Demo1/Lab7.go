package main
import (
	"fmt"
	"strconv"
)
type Emp struct {
	empno int 
	ename string
	salary int
}
type EmpManager struct {
	emparr []Emp 
}

func (empmgr *EmpManager) add(e1 Emp){
	empmgr.emparr = append(empmgr.emparr, e1)
}
func (empmgr *EmpManager) print(){
	for i, v := range empmgr.emparr {
		fmt.Println("i = ",  i, "Value = ", v)
	}
}
func main(){
	empmgr:=EmpManager{}
	for i:=1; i< 10; i++{
		e1 := Emp{i,"Nameof"+strconv.Itoa(i),i*1000}
		empmgr.add(e1)
	}
	empmgr.print()

}
