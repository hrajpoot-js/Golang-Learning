package main

import (
	"fmt"
)
type Point2D struct {
	x int
	y int
}
// Pass by Value
/*
func shift(pt Point2D){
	fmt.Println("Original Shift Line1 - " , pt)
	pt.x = pt.x + 10
	pt.y = pt.y + 20
	fmt.Println("Original Shift Line4 - " , pt)
}
*/
func (pt Point2D) shift1(){
	fmt.Println(" Shift1 Line1 - " , pt)
	pt.x = pt.x + 10
	pt.y = pt.y + 20
	fmt.Println("Shift2 Line4 - " , pt)
}
func (pt *Point2D) shift2(){
	fmt.Println(" Shift1 Line1 - " , pt)
	pt.x = pt.x + 10
	pt.y = pt.y + 20
	fmt.Println("Shift2 Line4 - " , pt)
}

func main(){
	p1 := Point2D{y : 10,x : 40}
	fmt.Println("x = ", p1.x , " y = ", p1.y)
	p1.shift1()
	fmt.Println("In Main " , p1)
	p1.shift2()
	fmt.Println("In Main " , p1)
}
