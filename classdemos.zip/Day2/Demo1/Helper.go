package common
func Add(x int, y int) int {
	return x + y
}
func Divide(x int, y int) int {
	return x / y
}

