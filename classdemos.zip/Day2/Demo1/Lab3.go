	package main

	import (
		"fmt"
	)
	type Emp struct {
		empno int 
		ename string
		salary int
	}
	func (emp Emp) print(){
		fmt.Println("Print Emp - empno=", emp.empno ," , ename=", emp.ename ,", salary = ", emp.salary )
		
	}
	func (emp *Emp) incrSalary(percent int){
		emp.salary = emp.salary + ( emp.salary*percent/100)
	}

	func main(){
		emp := Emp{1,"Vaishali",1000}
		const e1 = Emp{1,"aa",11}
		e1.print()
		emp.incrSalary(10)
		emp.print()
	}
